# Atlas Premium UI Prototype

This archive is a starter scaffold only.

Recommended build order:
1. Fleet Dashboard
2. Node Overview
3. Services
4. Containers
5. Processes
6. Alerts
7. Events
8. Logs
9. Settings
